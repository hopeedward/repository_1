/* This revision is automatically updated by the Makefile script */
var LANTERN_BUILD_REVISION = "?";
