bytecounting [![Travis CI Status](https://travis-ci.org/getlantern/bytecounting.svg?branch=master)](https://travis-ci.org/getlantern/bytecounting)&nbsp;[![Coverage Status](https://coveralls.io/repos/getlantern/bytecounting/badge.png)](https://coveralls.io/r/getlantern/bytecounting)&nbsp;[![GoDoc](https://godoc.org/github.com/getlantern/bytecounting?status.png)](http://godoc.org/github.com/getlantern/bytecounting)
==========
go library for counting bytes read/written on net.Conn and net.Listener.

[GoDoc](https://godoc.org/github.com/getlantern/bytecounting)