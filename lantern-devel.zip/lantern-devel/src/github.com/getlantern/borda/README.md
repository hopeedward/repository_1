# Borda

[![wercker status](https://app.wercker.com/status/d63b521240d1cea1c2fb71061b9e3272/m "wercker status")](https://app.wercker.com/project/bykey/d63b521240d1cea1c2fb71061b9e3272)

Borda, named after
[Jean-Charles de Borda](https://en.wikipedia.org/wiki/Jean-Charles_de_Borda), is
a collection point for metrics from
[Lantern](https://github.com/getlantern/lantern) clients and servers.

## REST API
[REST API Docs](http://getlantern.github.io/borda/)
