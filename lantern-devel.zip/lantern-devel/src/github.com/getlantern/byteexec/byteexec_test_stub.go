// +build !windows

package byteexec

const linefeed = "\n"
