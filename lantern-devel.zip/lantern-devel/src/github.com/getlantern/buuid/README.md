buuid [![Travis CI Status](https://travis-ci.org/getlantern/buuid.svg?branch=master)](https://travis-ci.org/getlantern/buuid)&nbsp;[![Coverage Status](https://coveralls.io/repos/getlantern/buuid/badge.png)](https://coveralls.io/r/getlantern/buuid)&nbsp;[![GoDoc](https://godoc.org/github.com/getlantern/buuid?status.png)](http://godoc.org/github.com/getlantern/buuid)
==========
buuid provides a type 4 UUID that can be encoded into a 16 byte binary
representation.

To install:

`go get github.com/getlantern/buuid`

For docs:

`godoc github.com/getlantern/buuid`
