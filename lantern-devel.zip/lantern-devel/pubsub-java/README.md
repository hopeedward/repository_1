# pubsub-java

This is the Java client API for [pubsub](https://github.com/getlantern/pubsub).

See [LongRunningClient.java](src/test/java/org/getlantern/pubsub/LongRunningClient.java)
for an example of how to use the API.